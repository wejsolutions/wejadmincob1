<div id="datocontrato"></div>
<script>
	load('vst-contrato-buscarContratosCte','','#datocontrato');
</script>