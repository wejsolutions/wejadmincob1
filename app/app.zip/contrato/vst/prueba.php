<?php 
echo "Prueba";
 ?>